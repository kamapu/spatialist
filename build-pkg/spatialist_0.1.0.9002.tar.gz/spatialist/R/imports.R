#' @importFrom adehabitatMA morphology
#' @importFrom methods as
#' @importFrom raster calc cellStats extent overlay raster res res<-
#' @importFrom sp coordinates coordinates<- proj4string proj4string<- CRS
#'     Polygon Polygons SpatialPolygons SpatialPolygonsDataFrame spTransform
#' @importFrom stats dist
#' @importFrom terra app crs ext global project
#' @importClassesFrom terra SpatRaster
NULL
