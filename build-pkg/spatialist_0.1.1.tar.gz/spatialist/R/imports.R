#' @importFrom methods exportMethods
#' @importFrom mmand dilate erode shapeKernel
#' @importFrom stats dist
#' @importFrom terra app as.array as.factor c coltab<- crs ext global project
#'      rast
#' @importClassesFrom terra SpatRaster
NULL
