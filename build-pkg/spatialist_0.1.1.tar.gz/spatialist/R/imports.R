#' @importFrom methods exportMethods
#' @importFrom mmand dilate erode shapeKernel
#' @importFrom stats dist
#' @importFrom terra app crs ext global project rast
#' @importClassesFrom terra SpatRaster
NULL
