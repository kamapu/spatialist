# spatialist v0.2

### Improvements

- Functions for raster data sets adapted to `SpatRaster` class of the package
  `terra`.

