#' @importFrom mmand dilate erode shapeKernel
#' @importFrom stats dist
#' @importFrom terra app coltab<- crs ext global project rast
#' @importClassesFrom terra SpatRaster
#' @importMethodsFrom terra as.array as.factor c
NULL
